importScripts('https://www.gstatic.com/firebasejs/10.7.1/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/10.7.1/firebase-messaging-compat.js');

firebase.initializeApp({
  apiKey: "AIzaSyA1TfeVDvVD1vMRZqEZfnoTz25_eojyv4k",
  authDomain: "myapphub-797c2.firebaseapp.com",
  databaseURL: "https://myapphub-797c2-default-rtdb.firebaseio.com",
  projectId: "myapphub-797c2",
  storageBucket: "myapphub-797c2.firebasestorage.app",
  messagingSenderId: "806012202139",
  appId: "1:806012202139:android:e3c284ab803790195b2a3e"
});

const messaging = firebase.messaging();

messaging.onBackgroundMessage((payload) => {
  console.log('[firebase-messaging-sw.js] Received background message ', payload);
  
  const notificationTitle = payload.notification.title;
  const notificationOptions = {
    body: payload.notification.body,
    icon: '/vite.svg'
  };

  self.registration.showNotification(notificationTitle, notificationOptions);
});
